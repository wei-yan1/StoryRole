"""The RoleRAG bridge must not become a second conversation controller.

These tests pin the ownership boundary introduced after the architecture
review: RoleRAG supplies visible memory, but history, mode, cognition,
validation and persistence stay in the old CharacterConversationAgent.
"""

from __future__ import annotations

import asyncio
from contextlib import nullcontext

from app.agents.storyrole.character_agent import CharacterConversationAgent
from app.agents.storyrole import character_agent as character_module
from app.agents.a2a import registry as registry_module
from app.rag.rolerag import api_adapter


class _Trace:
    trace_id = "test-trace"

    def start(self) -> None:
        pass

    def step(self, *_args, **_kwargs):
        return nullcontext()

    def finish(self, *_args, **_kwargs) -> None:
        pass


class _Prepared:
    messages = [{"role": "user", "content": "上一轮"}]
    summary = "上一轮摘要"


class _FakeA2A:
    async def send(self, agent_id, payload):
        if agent_id == "context-curator":
            return {"context": {"profile": {"identity": "面壁者"}, "novel_evidence": []}}
        if agent_id == "character-reasoning":
            return {"response_action": "先承接情绪，再保留立场"}
        if agent_id == "memory-decision":
            return {"requires_confirmation": False, "should_save": False}
        return {}


def test_role_retrieval_keeps_history_and_old_generation_path(monkeypatch) -> None:
    captured: dict[str, object] = {}

    monkeypatch.setattr(character_module, "TraceContext", lambda **_kwargs: _Trace())
    async def fake_prepare_history(**_kwargs):
        return _Prepared()

    monkeypatch.setattr(
        "app.services.chat_context_compaction.prepare_history",
        fake_prepare_history,
    )
    monkeypatch.setattr(
        character_module,
        "get_persona_profile_for_period",
        lambda **_kwargs: {"profile": {"identity": "面壁者", "goals": ["守住庄颜"]}, "version": 22},
    )
    monkeypatch.setattr(
        character_module,
        "get_character",
        lambda **_kwargs: {"canonical_name": "罗辑", "novel_id": "novel-1"},
    )
    monkeypatch.setattr(
        api_adapter,
        "retrieve_from_manifest",
        lambda *_args, **_kwargs: {
            "cutoff": 44,
            "route": "recall",
            "route_reason": "可见事实",
            "evidence": [{"id": "e1", "chunk_id": "e1", "text": "叶文洁提出公理", "kind": "fact"}],
            "ego_summary": "我眼里的他们：史强是能办事的人。",
            "profile_overlay": {"relationships": ["史强：护送我"], "known": ["两条公理"], "unknown": []},
            "boundary_source": "period_terms",
            "boundary_confidence": 0.75,
        },
    )
    monkeypatch.setattr(character_module.novel_import_service, "get_job", lambda *_args, **_kwargs: {})
    monkeypatch.setattr(character_module, "get_character_period", lambda **_kwargs: None)
    monkeypatch.setattr(character_module, "get_latest_period_analysis", lambda **_kwargs: None)
    monkeypatch.setattr(character_module, "list_characters", lambda **_kwargs: [])
    monkeypatch.setattr(registry_module, "client", _FakeA2A())
    monkeypatch.setattr(character_module.QueryPlannerAgent, "plan", lambda _self, _payload: {
        "intent": "emotion", "needs_memory": False, "needs_relationship": False,
        "needs_timeline_check": False, "decision_backend": "rule_fallback",
    })

    async def fake_run_agent(self, **kwargs):
        captured.update(kwargs)
        return "我在。"

    monkeypatch.setattr(CharacterConversationAgent, "_run_agent", fake_run_agent)
    async def fake_update_relationship(*_args, **_kwargs):
        return None

    monkeypatch.setattr(
        CharacterConversationAgent,
        "_update_relationship",
        fake_update_relationship,
    )
    monkeypatch.setattr(
        CharacterConversationAgent,
        "_persist_memory_candidate",
        lambda *_args, **_kwargs: None,
    )
    monkeypatch.setattr(
        CharacterConversationAgent,
        "_record_evidence_graph",
        lambda *_args, **_kwargs: None,
    )

    payload = {
        "owner_id": 2,
        "novel_id": "novel-1",
        "character_id": 1,
        "period_id": 7,
        "message": "我今天很难过",
        "thread": {"id": 11},
        "mode": "quick",
        "web_mode": "off",
        "debug": True,
    }
    result = asyncio.run(CharacterConversationAgent().reply(payload))

    assert result["answer"] == "我在。"
    assert result["engine"] == "rolerag"
    assert result["cutoff"] == 44
    assert result["profile_injected"] is True
    assert captured["recent_messages"] == [{"role": "user", "content": "上一轮"}]
    assert "面壁者" in captured["persona_contract"]
    role_context = captured["context"]["role_context"]
    assert role_context["ego_summary"].startswith("我眼里的他们")
    assert role_context["profile_overlay"]["known"] == ["两条公理"]
    assert result["persona_fidelity"]["ok"] is True
