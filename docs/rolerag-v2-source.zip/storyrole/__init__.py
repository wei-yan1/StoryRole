"""Dynamic StoryRole agents."""
