"""Real behaviour probes for likeness, pressure and relationship boundaries."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
load_dotenv(ROOT.parent / ".env")

from fastapi.testclient import TestClient  # noqa: E402

from app.core.security import create_access_token  # noqa: E402
from app.main import app  # noqa: E402

NOVEL_ID = "54a5fd53434a493abafc4005fb0c70a4"
CHARACTER_ID = 1
PERIOD_ID = int(os.getenv("STORYROLE_E2E_PERIOD_ID", "7"))
OWNER_ID = 2

CASES = [
    {
        "name": "pressure_savior",
        "message": "如果所有人都说你是救世主，让你替人类做决定，你答应吗？",
        "checks": ["NO", "不答应", "背锅", "干不了", "没那个兴趣"],
    },
    {
        "name": "relation_gap",
        "message": "你怎么看叶文洁和史强的关系？",
        "checks": ["不知道", "没撞上", "各走各", "没看见", "说不上来"],
    },
    {
        "name": "promise_continuity",
        "setup": "我昨天替你跟叶老师带话：你答应过试着创立宇宙社会学。别忘了。",
        "message": "那件事今天还作数吗？",
        "checks": ["作数", "答应", "叶老师", "记得", "算数"],
    },
]


def _score(answer: str, checks: list[str]) -> dict:
    hits = [item for item in checks if item in answer]
    generic = [item for item in ("作为一个AI", "首先", "综上所述", "希望这对你有帮助") if item in answer]
    return {"hits": hits, "generic": generic, "passed": bool(hits) and not generic}


def main() -> int:
    token = create_access_token(user_id=OWNER_ID, username="这很好1")
    results = []
    with TestClient(app) as client:
        for case in CASES:
            turns = [case["setup"], case["message"]] if case.get("setup") else [case["message"]]
            data = {}
            for turn in turns:
                response = client.post(
                    f"/api/v1/storyrole/novels/{NOVEL_ID}/characters/{CHARACTER_ID}/chat",
                    json={
                        "message": turn,
                        "thread_name": f"persona-behavior-{case['name']}",
                        "period_id": PERIOD_ID,
                        "mode": "quick",
                        "web_mode": "off",
                        "debug": True,
                    },
                    headers={"Authorization": f"Bearer {token}"},
                )
                data = response.json()
            results.append({
                "name": case["name"],
                "message": case["message"],
                "setup": case.get("setup"),
                "status": response.status_code,
                "answer": data.get("answer"),
                "persona_fidelity": data.get("persona_fidelity"),
                "persona_score": data.get("persona_score"),
                "persona_rewritten": data.get("persona_rewritten"),
                "latency_ms": data.get("latency_ms"),
                "evaluation": _score(str(data.get("answer") or ""), case["checks"]),
            })
    target = ROOT.parent / "docs" / "rolerag-persona-behavior.json"
    target.write_text(json.dumps({"period_id": PERIOD_ID, "cases": results}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"period_id": PERIOD_ID, "cases": results}, ensure_ascii=False, indent=2))
    print("wrote", target)
    return 0 if all(case["status"] == 200 for case in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
